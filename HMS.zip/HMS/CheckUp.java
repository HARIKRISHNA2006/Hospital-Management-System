
import java.io.File;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
import javax.swing.JOptionPane;
import jdk.nashorn.internal.parser.TokenType;


public class CheckUp extends javax.swing.JFrame {
    
    
        ArrayList<BillingInfo> allRecords= new ArrayList<>();
         ArrayList<Medicine> allMedicines = new ArrayList<>();
         ArrayList<Patient> allPatients = new ArrayList<>();

    public CheckUp() {
        initComponents();
        readAllMData();
        readAllPData();
       readAllRData();
        LoadMed();
      
    }
    
       void readAllRData()
    {
            try {
            File pfile= new File("record.txt");
            Scanner scanner = new Scanner(pfile);
            
                while (scanner.hasNextLine()) {

                  String data = scanner.nextLine();
                  String[] curData = data.split(";");   
                    BillingInfo record = new BillingInfo();
                  record.setPatientID(Integer.parseInt(curData[0]));
                  
                 record.setFee(Integer.parseInt(curData[1]));
                 record.setRecomendations(curData[2]); 
                 record.setDate(curData[3]);
                 
                 String []mlist =curData[4].split(",");
                 
                 for(int i=0;i<mlist.length;i++)
                 {
                 record.setMedicineID(Integer.parseInt(mlist[i]));
                 
                 }
                 
                 
                 allRecords.add(record);
                   
                }
                
              scanner.close();
                
        } catch (Exception e) {
        }
    
    
    }  

    
    
    void LoadMed()
    {
        allM.removeAllItems();
        for(int i=0;i<allMedicines.size();i++)
             {
             allM.addItem(allMedicines.get(i).getId()+";"+allMedicines.get(i).getName());
             
             }
    
    }
    
    
    void readAllPData()
    {
            try {
            File pfile= new File("pdata.txt");
            Scanner scanner = new Scanner(pfile);
            
                while (scanner.hasNextLine()) {

                  String data = scanner.nextLine();
                  String[] curData = data.split(";");  
                  Patient patient = new Patient();
                  patient.setId(Integer.parseInt(curData[0]));
                  
                  patient.setName(curData[1]);
                 patient.setAge(Integer.parseInt(curData[2]));
                 patient.setGender(curData[3]); 
                 patient.setAddress(curData[4]);
                 patient.setContact(curData[5]);
                 allPatients.add(patient);
                   
                   
                }
                
              scanner.close();
                
        } catch (Exception e) {
        }
    
    
    }
      
    void readAllMData()
    {
            try {
            File pfile= new File("mdata.txt");
            Scanner scanner = new Scanner(pfile);
            
                while (scanner.hasNextLine()) {

                  String data = scanner.nextLine();
                  String[] curData = data.split(";"); 
                    Medicine medicines = new Medicine();
                  medicines.setId(Integer.parseInt(curData[0]));
                  
                  medicines.setName(curData[1]);
                 medicines.setSellingPrice(Integer.parseInt(curData[2]));
                 medicines.setBuyingPrice(Integer.parseInt(curData[3])); 
                 medicines.setQuantity(Integer.parseInt(curData[4]));
                 medicines.setDescription(curData[5]);
                 allMedicines.add(medicines);
                   
                   
                }
                
              scanner.close();
                
        } catch (Exception e) {
        }
    
    
    }

    
    
    

    @SuppressWarnings("unchecked")
    
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        id = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        allM = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        mList = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        fee = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        rec = new javax.swing.JTextArea();
        jLabel8 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        quantity = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/checkup.png"))); 

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 24)); 
        jLabel2.setForeground(new java.awt.Color(0, 153, 51));
        jLabel2.setText("Checkup Menu");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 14)); 
        jLabel3.setText("Algopk Hospital");

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 18)); 
        jButton3.setForeground(new java.awt.Color(0, 153, 51));
        jButton3.setText("Home");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(jLabel2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(58, 58, 58)
                        .addComponent(jLabel3)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(0, 998, Short.MAX_VALUE)
                    .addComponent(jButton3)
                    .addGap(32, 32, 32)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(21, 21, 21)
                    .addComponent(jButton3)
                    .addContainerGap(50, Short.MAX_VALUE)))
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); 
        jLabel4.setText("Patient ID");

        id.setFont(new java.awt.Font("Tahoma", 1, 12)); 

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); 
        jLabel5.setText("Medicines");

        allM.setFont(new java.awt.Font("Tahoma", 1, 12)); 
        allM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        allM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                allMActionPerformed(evt);
            }
        });

        mList.setColumns(20);
        mList.setRows(5);
        jScrollPane1.setViewportView(mList);

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 18)); 
        jButton1.setForeground(new java.awt.Color(0, 153, 51));
        jButton1.setText("Add Medicines");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); 
        jLabel6.setText("Medicines List");

        fee.setFont(new java.awt.Font("Tahoma", 1, 12)); 

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); 
        jLabel7.setText("Fee");

        rec.setColumns(20);
        rec.setRows(5);
        jScrollPane2.setViewportView(rec);

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); 
        jLabel8.setText("Recomendations");

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 18)); 
        jButton2.setForeground(new java.awt.Color(0, 153, 51));
        jButton2.setText("Save");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); 
        jLabel9.setText("Quantity");

        quantity.setFont(new java.awt.Font("Tahoma", 1, 12)); 

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(id)
                    .addComponent(fee)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 269, Short.MAX_VALUE))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel5)
                            .addComponent(jLabel9))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGap(39, 39, 39)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 460, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(47, 47, 47)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(allM, 0, 452, Short.MAX_VALUE)
                                    .addComponent(quantity))))
                        .addContainerGap(21, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1)
                        .addGap(213, 213, 213))))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(438, 438, 438)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(allM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(fee, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel8))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(65, 65, 65))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(52, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        setSize(new java.awt.Dimension(1217, 724));
        setLocationRelativeTo(null);
    }

    
   
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

        setVisible(false);
        new Home().setVisible(true);

       
    }

    private void allMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_allMActionPerformed
        
    }

   boolean checkForQuantity()
    {
        int  currMId= Integer.parseInt(allM.getSelectedItem().toString().split(";")[0]);
        for(int i=0;i<allMedicines.size();i++)
        {
               if(currMId==allMedicines.get(i).getId())
               {
               
                   if(Integer.parseInt(quantity.getText())>allMedicines.get(i).getQuantity())
                      return true;
               }
        
        
        }
        
        
        
        
    return false;
    }
    
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    
  if(quantity.getText().equals("")|| allM.getSelectedItem().toString().equals(""))
  {
          JOptionPane.showMessageDialog(null,"Please Select Medicion Or Enter Quantity");
  
  }
  else if(checkForQuantity())
      
  {
  
  
          JOptionPane.showMessageDialog(null,"Current Quantity is greater then available quanitity ");
  
  
  }
  
    else
  {
  
    mList.append(allM.getSelectedItem()+";"+quantity.getText()+"\n");
    quantity.setText("");
  
  
  }
  
        
        
        

        
    }

   boolean  PatientIdExist()
   {
       
       for(int i=0;i<allPatients.size();i++)
       {
          if(id.getText().equals(allPatients.get(i).getId()+""))
          {
               return false;
          
          }
       
       }
       
       
   return true;
   }
   
     void SaveAllMData()
    {
          try {
            FileWriter fileWriter = new FileWriter("mdata.txt");
            
            for(int i=0;i<allMedicines.size();i++)
            {
              fileWriter.write(allMedicines.get(i).getId()+";"+allMedicines.get(i).getName()+";"+allMedicines.get(i).getSellingPrice()+";"+allMedicines.get(i).getBuyingPrice()+";"+allMedicines.get(i).getQuantity()+";"+allMedicines.get(i).getDescription()+"\n");
            
            }
              fileWriter.close();
              
        } catch (Exception e) {
        }
    
    }
     
     
       void SaveAllRData()
    {
          try {
            FileWriter fileWriter = new FileWriter("record.txt");
            
            for(int i=0;i<allRecords.size();i++)
            {
              fileWriter.append(allRecords.get(i).getPatientID()+";"+allRecords.get(i).getFee()+";"+allRecords.get(i).getRecomendations()+";"+allRecords.get(i).getDate()+";");
           ArrayList<Integer> tmp = allRecords.get(i).getMedicineID();
              for(int j=0;j<tmp.size();j++)
              {
              fileWriter.append(tmp.get(j)+",");
              
              }
            fileWriter.append("\n");
              
            }
              fileWriter.close();
              
        } catch (Exception e) {
        }
    
    }
    
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
   
     if(id.getText().equals("")||fee.getText().equals("")||rec.getText().equals(""))
     {
     
        JOptionPane.showMessageDialog(null,"All Feilds Are Required!");
     
     }
        
      else  if(PatientIdExist())
      {
        JOptionPane.showMessageDialog(null,"Patient Id Didn't Exists");
      
      }
      
    
      else 
      {
         
          try {
              
          BillingInfo billingInfo = new BillingInfo();
          
          String Bill="";
         int total=0;
         billingInfo.setPatientID(Integer.parseInt(id.getText()));
         billingInfo.setFee(Integer.parseInt(fee.getText()));
         String[] Mdata= mList.getText().split("\n");
         for(int i=0;i<Mdata.length;i++)
         {
           billingInfo.setMedicineID(Integer.parseInt(Mdata[i].split(";")[0]));
           int curQ= Integer.parseInt(Mdata[i].split(";")[2]);
           int curID= Integer.parseInt(Mdata[i].split(";")[0]);
           for(int j=0;j<allMedicines.size();j++)
           {
                if(allMedicines.get(j).getId()==curID)
                {
                
           Bill+=allMedicines.get(j).getName()+"  =   "+allMedicines.get(j).getSellingPrice()+"\n";
                    total+=allMedicines.get(j).getSellingPrice();
                allMedicines.get(j).setQuantity(allMedicines.get(j).getQuantity()-curQ);
                }
           
           }
         }
         billingInfo.setRecomendations(rec.getText());
         DateFormat cDateFormat = new SimpleDateFormat("dd:MM:yyyy");
         Date cdate= new Date();
         billingInfo.setDate(cDateFormat.format(cdate));
         
         allRecords.add(billingInfo);
         
        SaveAllMData();
        SaveAllRData();
        
        Bill+="\nTotal Medicines Cost = "+total;
        Bill+="\nDoctor Fee = "+fee.getText();
        
        Bill+="Total = "+ (total+Integer.parseInt(fee.getText()));
        
        
        JOptionPane.showMessageDialog(null, "Your Bill \n"+Bill);
        id.setText("");
        fee.setText("");
        rec.setText("");
        mList.setText("");
        
        
         
      
          } catch (Exception e) {
              System.out.println(e);
          }
          
      
      
      }
          
        
        


    }


    public static void main(String args[]) {

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CheckUp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CheckUp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CheckUp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CheckUp.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CheckUp().setVisible(true);
            }
        });
    }

    private javax.swing.JComboBox<String> allM;
    private javax.swing.JTextField fee;
    private javax.swing.JTextField id;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea mList;
    private javax.swing.JTextField quantity;
    private javax.swing.JTextArea rec;

}
